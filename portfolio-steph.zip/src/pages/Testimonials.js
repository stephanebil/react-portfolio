import React from 'react'
import Layout from "../components/layouts/Layout";
import TestimonialsSection1 from '../components/TestimonialsPage/TestimonialsSection1';

export default function Testimonials() {
  return (
    <Layout><TestimonialsSection1/></Layout>
  )
}
