import React from 'react'
import AboutSection1 from '../components/AboutPage/AboutSection1';
import Layout from "../components/layouts/Layout";



export default function About() {
  return (
    <Layout>
    <AboutSection1/>
    </Layout>
  )
}
