import React from 'react'
import Layout from "../components/layouts/Layout";
import SkillsSection1 from '../components/SkillsPage/SkillsSection1';

export default function Skills() {
  return (
    <Layout><SkillsSection1/></Layout>
  )
}
