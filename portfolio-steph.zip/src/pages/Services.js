import React from 'react'
import Layout from "../components/layouts/Layout";
import ServicesSection1 from '../components/ServicesPage/ServicesSection1';

export default function Services() {
  return (
    <Layout><ServicesSection1/></Layout>
  )
}
